/* 
THIS FILE IS FOR THE ALT:V INSTALLER POSTINSTALL! 
DO NOT INCLUDE IT IN YOUR PROJECT IF YOU INSTALL IT MANUALLY!
*/

const COLORS = {
    Reset: "\x1b[0m",
    FgGreen: "\x1b[32m",
    FgCyan: "\x1b[36m",
};

console.log(`${COLORS.FgGreen}|-----------------------------------------|`);
console.log(`${COLORS.FgGreen}|${COLORS.Reset}  Thank you for installing my resource!  ${COLORS.FgGreen}|`);
console.log(`${COLORS.FgGreen}|${COLORS.Reset}          Made by ${COLORS.FgCyan}LeonMrBonnie           ${COLORS.FgGreen}|`);
console.log(`${COLORS.FgGreen}|-----------------------------------------|`);