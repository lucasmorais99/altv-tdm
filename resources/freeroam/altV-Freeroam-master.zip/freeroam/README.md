# altV-Freeroam

---

Remember to 🌟 this Github if you 💖 it.

---

### Requires:
* [altV-Extended](https://github.com/team-stuyk-alt-v/altV-Extended)
* [altV-Chat-Extended](https://github.com/team-stuyk-alt-v/altV-Chat-Extended)

### Commands:
```
* /kill
* /wep [wep_name], /weapon [wep_name], /giveweapon [wep_name]
* /veh, /vehicle [vehicle_name]
* /vehiclecolor1 [r, g, b]
* /vehiclecolor2 [r, g, b]
* /clearweapons, /clearweapon, /clearwep
* /position, /pos
* /tpto [playername]
* /tp [x] [y] [z]
* /skin [skin_name]
* /dimension [number], /setdimension [number]
* /invitedimension [player_name], /invitedim [player_name]
* /joindim
* /kickdim [player_name]
```